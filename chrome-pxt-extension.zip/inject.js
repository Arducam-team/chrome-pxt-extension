(function(){
    if (window.location.href == "https://makecode.microbit.org/#editor") {
        // console.log("wait")
        let interval = setInterval(function() {
            if (document.getElementById('root')) {
                // alert("===== extension load ok =====")
                // console.log(document.getElementById('root'))
                clearInterval(interval)
                let elImg = document.createElement('img')
                elImg.style.cssText = "right: 10px;position: absolute;width: 320px;height: 240px;top: 60px;max-width: 640px;max-height: 480px;width: auto;height: auto;";
                elImg.classList.value = "animating transition fade out"
                document.getElementById('root').appendChild(elImg);
                
                let imgData = new Uint8Array(0);
                let isStart = false;
                let isEnd = false;
                let before = -1;
                
                window.addEventListener('message', function(ev){
                    if(ev.data.type=== "serial") {
                        // if (ev.data.data === "cap end") {
                        //     // show image
                        //     elImg.src = "data:image/jpg;base64," + abToB64(imgData);
                        //     imgData = new Uint8Array(0);
                        //     flash();
                        // } else if (ev.data.data === "cap start") {
                        //     console.log("cap start")
                        //     imgData = bfMerge(imgData,str2buf(ev.data.data))
                        // }
                
                        let buf = str2buf(ev.data.data);
                        if (isStart) {
                            // console.log("====== image start ======")
                            imgData = bfMerge(imgData,buf)
                        }
                
                        if (isEnd) {
                            // console.log("====== image end ======")
                            isEnd = false
                            isStart = false
                            elImg.src = "data:image/jpg;base64," + abToB64(imgData);
                            
                            imgData = new Uint8Array(0);
                            flash();
                        }
                        
                        
                        
                        
                    }
                },false)
                
                
                
                
                
                
                // animating transition flash
                function flash() {
                    elImg.classList.remove('out')
                    elImg.classList.add('flash')
                    setTimeout(function() {
                        elImg.classList.remove('flash')
                    }, 3000)
                }
                
                
                
                
                
                
                function str2buf(data) {
                    let buf = new ArrayBuffer(data.length);
                    let bufView = new Uint8Array(buf);
                    for (var i=0, strLen=data.length; i<strLen; i++) {
                        let c = data.charCodeAt(i);
                        bufView[i] = c;
                        // console.log(c)
                        if (c == 216 && before == 255) {
                            isStart = true
                        } else if (c == 217 && before == 255) {
                            isEnd = true
                        }
                        before = c;
                    }
                    return buf;
                }
                
                function abToB64( buffer ) {
                    let binary = '';
                    let bytes = new Uint8Array( buffer );
                    let len = bytes.byteLength;
                    for (let i = 0; i < len; i++) {
                        binary += String.fromCharCode( bytes[ i ] );
                    }
                    return window.btoa( binary );
                }
                
                function bfMerge(bf1, bf2) {
                    let tmp = new Uint8Array(bf1.byteLength + bf2.byteLength);
                    tmp.set(new Uint8Array(bf1), 0);
                    tmp.set(new Uint8Array(bf2), bf1.byteLength);
                    return tmp.buffer;
                }
                
                
            } else {
                // console.log("wait")
            }
        }, 1000)
    }
    
    
    
  
    
})()
